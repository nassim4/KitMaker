<?php

namespace Kit\MakerBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Kit\MakerBundle\Entity\Enquiry;
use Kit\MakerBundle\Form\EnquiryType;
use Symfony\Component\Form\FormBuilderInterface; 
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\Response;


class DefaultController extends Controller
{

    public function indexAction()
    {


        $command = 'pdftk /var/www/html/KitMaker/web/pdf/Kit_Bienvenida.pdf dump_data_fields';
        $output = array();
        exec( $command , $output );

        $fieldNames = array();
        $datos = array();
        $mensage="Datos de acceso.";

        foreach ($output as $key => $v) {
            $pos = strpos($v, "FieldName:");
            if($pos !== false) {
                $auxArray = split(':', $v);
                $fieldName = trim($auxArray[1]);
                $fieldNames[$key] = $fieldName;
                print_r($fieldName.'</br>');
                
            }               
        }

        $content= $this->render('KitMakerBundle:Default:formulario.html.twig', array(
            'campos' => $fieldNames,
            'content'=> 'email desde irontec: bienvenido, con este email te mandamos el kit de bienvenida con los datos de acceso.'));

        return new Response($content);
    }

    public function bienvenidoAction(Request $request)
    {
        
        //$data = $form->getData();
        // $data is an instance of SMTC\MainBundle\Model\Task
        $input = array();
        unset($input);
        $data= $request->request->all();
        echo "11111111111111111111111111111111111111111<br>";
        print_r($data);
        
        if ('POST' === $request->getMethod())
        {
            echo "22222222222222222222222222<br>";
            //$form->handlerequest($request);
            
            /*$input['name'] = $request->request->get('name');
            $input['email'] = $request->request->get('email');
            $input['subject'] = $request->request->get('subject');
            $input['body'] = $request->request->get('body');*/
                       
                //print_r($value.' = '.$data[$value].'</br>');
                //$input[$value] = $data[$value];

                foreach ($data as $key => $value) {
                    echo "333333333333333333333333333333333<br>";
                    print_r('$input-----'.$key.'</br>');
                    print_r('$input-----'.$value.'</br>');
                    if($value == ''){
                        echo "44444444444444444444444444444444444444<br>";
                        print_r('$input-----'.$key.'</br>');
                        print_r('$input-----'.$value.'</br>');
                    $mensage= 'has dejado algun campo vacio.';
                return $this->render('KitMakerBundle:Default:index.html.twig', array(
                    'msg' => $mensage,
                    ));           
                    //$mensage="Has incertado un nuevo actor";                    
                }                               
            }
            echo "todo esta bien";
        }
        echo "55555555555555555555555555555555555555<br>";

        return $this->redirectToRoute('kit_maker_generate', array(
                'data'=> $data
            ));       
    }   

    public function generateAction()
{
   
   return $this->redirectToRoute('kit_maker_homepage');

}


}
