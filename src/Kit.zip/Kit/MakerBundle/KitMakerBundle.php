<?php

namespace Kit\MakerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KitMakerBundle extends Bundle
{
}
